import json as JSON
import bcrypt  ## For hashing and salting
import random
import numpy


def lambda_handler(event, context):
    
    reqbody = JSON.loads(event['body'])
    username = reqbody['username']
    password = reqbody['password']
    
    print('Account creation started for user \'' + username + '\'.')
    
    return {
        'statusCode': 200,
        'headers' : {
            'Access-Control-Allow-Origin': '*' ##Required for CORS support to work
            ## 'Access-Control-Allow-Credentials': true ## Required for cookies, authorization headers with HTTPS
        },
        #'body': JSON.dumps(event)
        'body' : JSON.dumps('Your account is created.')
    }

